# Pie Orders
This is your Sweet Potato Pie fundraiser site (Vite + React).

## Run locally
```
npm install
npm run dev
```

## Build
```
npm run build
```
Deploy the `dist/` folder to Netlify (manual) or connect the repo to Netlify with:
- Build command: `npm run build`
- Publish directory: `dist`
